//
//  ASViewController.h
//  PopoversTest
//
//  Created by Oleksii Skutarenko on 06.01.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASViewController : UIViewController

- (IBAction) actionAdd:(UIBarButtonItem*)sender;
- (IBAction) actionPressMe:(UIButton*)sender;

@end
