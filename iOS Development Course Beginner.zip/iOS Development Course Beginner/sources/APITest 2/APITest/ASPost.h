//
//  ASPost.h
//  APITest
//
//  Created by Oleksii Skutarenko on 14.03.14.
//  Copyright (c) 2014 Alex Skutarenko. All rights reserved.
//

#import "ASServerObject.h"

@interface ASPost : ASServerObject

@property (strong, nonatomic) NSString* text;

@end
