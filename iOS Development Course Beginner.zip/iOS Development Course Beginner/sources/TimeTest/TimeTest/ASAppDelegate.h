//
//  ASAppDelegate.h
//  TimeTest
//
//  Created by Oleksii Skutarenko on 04.11.13.
//  Copyright (c) 2013 Alex Skutarenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
