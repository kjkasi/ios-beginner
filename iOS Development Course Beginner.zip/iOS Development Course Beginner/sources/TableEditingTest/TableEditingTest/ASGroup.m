//
//  ASGroup.m
//  TableEditingTest
//
//  Created by Oleksii Skutarenko on 23.12.13.
//  Copyright (c) 2013 Alex Skutarenko. All rights reserved.
//

#import "ASGroup.h"

@implementation ASGroup

@end
