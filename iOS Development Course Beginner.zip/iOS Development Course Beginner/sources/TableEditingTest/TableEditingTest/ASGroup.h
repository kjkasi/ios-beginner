//
//  ASGroup.h
//  TableEditingTest
//
//  Created by Oleksii Skutarenko on 23.12.13.
//  Copyright (c) 2013 Alex Skutarenko. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASGroup : NSObject

@property (strong, nonatomic) NSString* name;
@property (strong, nonatomic) NSArray* students;

@end
